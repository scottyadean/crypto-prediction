# Crypto Perdiction Script
a simple script to predict crypto prices

# Setup
``` bash pip install -r requirements.txt  ```

# Usage
### Analyze specific coins with more history
```python crypto_predict.py --source tiingo --days 1095 --coins BTC ETH SOL ADA DOGE AVAX```

### Show only the top 5 ranked
```python crypto_predict.py --source tiingo --top 5 ```

### Extend lookback window for more training data
```python crypto_predict.py --source tiingo --days 1095 ```